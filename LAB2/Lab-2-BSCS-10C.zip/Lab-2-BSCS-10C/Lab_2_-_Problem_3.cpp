/*
* Kindly fill this information.
* Name:
* Student #: 
* Date: 12/09/13
*/

#include <iostream>
#include <string>

using namespace std;

/*
* Define a struct Area that has two private variable members;
* units of type string and area_value of type float.
*/
struct Area
{
	// Add your code here!
	
};

int main()
{
	/*
	* Modify program to create a dynamic variable of type Area.
	*/
	
	// Add your code here!


	/*
	* Input from the keyboard the area_value and its units.
	*/
	
	// Add your code here!
	
	
	/*
	* Compute one-half and one-quarter of the area 
	* and display the results 
	*/
	
	// Add your code here!
	

	/*
	* Destroy the dynamic variable at the end
	*/
	
	// Add your code here!
	
	
	return 0;
}